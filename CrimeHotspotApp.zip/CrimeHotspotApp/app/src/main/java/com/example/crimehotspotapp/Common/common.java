package com.example.crimehotspotapp.Common;

import android.location.Location;

public class common {
    public static Location currentLocation;

}
