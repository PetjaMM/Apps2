package com.example.carrerconcellingapp.Interface;

import android.view.View;

public interface ItemClickListener {
    void onClick(View view, int Position, Boolean isLongClick);
}
