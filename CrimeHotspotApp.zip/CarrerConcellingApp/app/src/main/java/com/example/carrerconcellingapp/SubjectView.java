package com.example.carrerconcellingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SubjectView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject_view);
    }
}