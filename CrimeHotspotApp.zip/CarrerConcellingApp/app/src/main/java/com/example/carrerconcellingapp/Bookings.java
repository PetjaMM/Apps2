package com.example.carrerconcellingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Bookings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookings);
    }
}