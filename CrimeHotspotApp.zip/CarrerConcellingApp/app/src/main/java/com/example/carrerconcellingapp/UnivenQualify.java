package com.example.carrerconcellingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UnivenQualify extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_univen_qualify);
    }
}